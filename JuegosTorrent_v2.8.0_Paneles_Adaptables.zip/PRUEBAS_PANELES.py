"""Pruebas del reparto inicial y respeto del divisor, sin abrir Tk."""
import ast
import types
import unittest
from pathlib import Path
from unittest.mock import patch

SOURCE=next(Path(__file__).resolve().parent.glob('Juegos_Torrent*.py'))
tree=ast.parse(SOURCE.read_text())
ns={'tk':types.SimpleNamespace(TclError=RuntimeError)}
layout=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='initial_panel_layout')
app=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='App')
names={'_on_main_paned_resize','_on_main_paned_press','_schedule_startup_split','_set_startup_split','_verify_startup_split'}
methods=[n for n in app.body if isinstance(n,ast.FunctionDef) and n.name in names]
exec(compile(ast.Module(body=[layout]+methods,type_ignores=[]),'layout','exec'),ns)

class Pane:
    def __init__(self,width):self.width=width;self.x=950;self.moves=[];self.limits={}
    def winfo_width(self):return self.width
    def winfo_ismapped(self):return True
    def paneconfigure(self,pane,**kwargs):self.limits[pane]=kwargs
    def sash_place(self,index,x,y):self.x=x;self.moves.append(x)
    def sash_coord(self,index):return self.x,1

class App:
    def __init__(self,width):
        self.main_paned=Pane(width);self._catalog_pane='left';self._detail_pane='right'
        self._startup_split_done=False;self._startup_split_job=None;self.jobs=[]
    def after(self,delay,callback):self.jobs.append((delay,callback));return len(self.jobs)
    def after_cancel(self,job):pass
for name in names:setattr(App,name,ns[name])

class Tests(unittest.TestCase):
    def test_resolutions(self):
        for screen,expected in ((1360,3),(1366,3),(1600,4),(1920,5),(2560,5)):
            with self.subTest(screen=screen):
                width=screen-36
                left,lmin,rmin=ns['initial_panel_layout'](width)
                canvas=left-11
                columns=min(5,max(1,(canvas-16)//172))
                self.assertEqual(columns,expected)
                self.assertGreaterEqual(width-6-left,rmin)
                self.assertGreaterEqual(left,lmin)
    def test_small_window(self):
        app=App(724);app._set_startup_split();app._verify_startup_split()
        self.assertTrue(app._startup_split_done)
        left,lmin,rmin=ns['initial_panel_layout'](724)
        self.assertLessEqual(lmin+rmin,718)
        self.assertEqual(app.main_paned.x,left)
    def test_real_width_used(self):
        app=App(1324);app._set_startup_split();app._verify_startup_split()
        self.assertEqual(app.main_paned.x,659)
    def test_startup_verification(self):
        app=App(1324);app._set_startup_split();app.main_paned.x=800
        app._verify_startup_split();self.assertEqual(app.main_paned.x,659)
    def test_user_drag_not_overridden(self):
        app=App(1324);app._set_startup_split()
        app._on_main_paned_press(types.SimpleNamespace(x=app.main_paned.x))
        app.main_paned.x=560;app._verify_startup_split()
        app._on_main_paned_resize(types.SimpleNamespace(widget=app.main_paned,width=1324))
        self.assertEqual(app.main_paned.x,560)
    def test_window_resize_after_manual(self):
        app=App(1884);app._set_startup_split();app._verify_startup_split()
        app.main_paned.width=1324;app.main_paned.moves=[]
        app._on_main_paned_resize(types.SimpleNamespace(widget=app.main_paned,width=1324))
        self.assertEqual(app.main_paned.moves,[])
    def test_inno7(self):
        import preparar_distribucion as builder
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            compiler=Path(d)/'Inno Setup 7/ISCC.exe';compiler.parent.mkdir();compiler.write_bytes(b'test')
            with patch.object(builder.shutil,'which',return_value=None),patch.dict(builder.os.environ,{'ISCC':'','ProgramFiles':d,'ProgramFiles(x86)':'','LOCALAPPDATA':''},clear=True):
                self.assertEqual(builder.find_iscc(),compiler)
    def test_inno_override(self):
        import preparar_distribucion as builder
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            compiler=Path(d)/'ISCC.exe';compiler.write_bytes(b'test')
            with patch.dict(builder.os.environ,{'ISCC':str(compiler)}):
                self.assertEqual(builder.find_iscc(),compiler)

if __name__=='__main__':unittest.main(verbosity=2)
