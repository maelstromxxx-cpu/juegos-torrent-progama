@echo off
setlocal
pushd "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 where py >nul 2>nul
 if errorlevel 1 (python -m venv .venv) else (py -3 -m venv .venv)
 if errorlevel 1 goto :error
)
".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,10), 'Se necesita Python 3.10 o posterior'"
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements-compilacion.txt
if errorlevel 1 goto :error
".venv\Scripts\python.exe" preparar_distribucion.py
if errorlevel 1 goto :error
echo EXE preparado. Ahora ejecuta CREAR_INSTALADOR.bat.
popd
pause
exit /b 0
:error
echo No se completo la compilacion. Conserva el mensaje de error.
popd
pause
exit /b 1
