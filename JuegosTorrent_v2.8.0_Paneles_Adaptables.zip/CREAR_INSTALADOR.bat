@echo off
setlocal
pushd "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Primero ejecuta COMPILAR_PORTATIL.bat.
 goto :error
)
".venv\Scripts\python.exe" preparar_distribucion.py --solo-instalador
if errorlevel 1 goto :error
popd
pause
exit /b 0
:error
echo No se completo el instalador. Lee el error de arriba.
popd
pause
exit /b 1
