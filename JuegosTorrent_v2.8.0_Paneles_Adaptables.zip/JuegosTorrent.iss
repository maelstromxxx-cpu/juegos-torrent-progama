#ifndef MyAppVersion
  #error Se debe compilar desde CREAR_INSTALADOR.bat o pasar /DMyAppVersion y /DSourceDir.
#endif
#ifndef SourceDir
  #error Falta la carpeta SourceDir.
#endif

[Setup]
AppId={{1DD27493-8ADB-49D1-92DC-4C96E96552AD}
AppName=Juegos Torrent
AppVersion={#MyAppVersion}
AppPublisher=Kalaka's Soft
DefaultDirName={localappdata}\Programs\KalakasSoft\JuegosTorrent
DefaultGroupName=Juegos Torrent
PrivilegesRequired=lowest
UsePreviousAppDir=yes
DisableProgramGroupPage=yes
OutputDir=INSTALADORES
OutputBaseFilename=JuegosTorrent_Setup_v{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\JuegosTorrent.exe
AppMutex=Local\KalakasSoft_JuegosTorrent
CloseApplications=yes
RestartApplications=no
SetupLogging=yes

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear acceso directo en el escritorio"; GroupDescription: "Accesos directos:"; Flags: unchecked

[Files]
Source: "{#SourceDir}\JuegosTorrent.exe"; DestDir: "{app}"; Flags: replacesameversion
; Los archivos externos solo se incorporan si faltan. Nunca borrar biblioteca al desinstalar.
Source: "{#SourceDir}\recursos\*"; DestDir: "{app}\recursos"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall
Source: "{#SourceDir}\tutoriales\*"; DestDir: "{app}\tutoriales"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\datos\*"; DestDir: "{app}\datos"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\imagenes\*"; DestDir: "{app}\imagenes"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\capturas\*"; DestDir: "{app}\capturas"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\sinopsis\*"; DestDir: "{app}\sinopsis"; Flags: recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\biblioteca_remota.json"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall
Source: "{#SourceDir}\actualizaciones.json"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall
Source: "{#SourceDir}\promociones_config.json"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist
Source: "{#SourceDir}\catalogo_cache.txt"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall skipifsourcedoesntexist

[Icons]
Name: "{group}\Juegos Torrent"; Filename: "{app}\JuegosTorrent.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\Juegos Torrent"; Filename: "{app}\JuegosTorrent.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\JuegosTorrent.exe"; Description: "Abrir Juegos Torrent"; Flags: nowait postinstall skipifsilent
