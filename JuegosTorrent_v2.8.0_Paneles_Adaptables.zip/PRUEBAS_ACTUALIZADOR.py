"""Pruebas locales sin red real ni cambios en una instalación existente."""
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import actualizador as u

class Response(io.BytesIO):
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

class Tests(unittest.TestCase):
    def release(self):
        return {'tag_name':'v2.8.0','assets':[{'name':'JuegosTorrent.exe','size':512,
            'browser_download_url':'https://github.com/owner/repo/releases/download/v2.8.0/JuegosTorrent.exe',
            'digest':'sha256:'+'a'*64}]}
    def test_release_new(self):
        self.assertEqual(u.select_release(self.release(),'2.7.99','owner/repo')['version'],'2.8.0')
    def test_release_old(self):
        self.assertIsNone(u.select_release(self.release(),'2.8.0','owner/repo'))
    def test_prerelease(self):
        r=self.release();r['prerelease']=True;self.assertIsNone(u.select_release(r,'2.7.99','owner/repo'))
    def test_setup_rejected(self):
        r=self.release();r['assets'][0]['name']='Setup.exe'
        with self.assertRaises(ValueError):u.select_release(r,'2.7.99','owner/repo')
    def test_missing_hash(self):
        r=self.release();r['assets'][0].pop('digest')
        with self.assertRaises(ValueError):u.select_release(r,'2.7.99','owner/repo')
    def test_wrong_repo(self):
        with self.assertRaises(ValueError):u.select_release(self.release(),'2.7.99','another/repo')
    def test_sidecar(self):
        r=self.release();r['assets'][0].pop('digest');r['assets'].append({'name':'JuegosTorrent.exe.sha256',
            'browser_download_url':'https://github.com/owner/repo/releases/download/v2.8.0/JuegosTorrent.exe.sha256'})
        with patch.object(u,'urlopen',return_value=Response(('b'*64+'  JuegosTorrent.exe\n').encode())):
            self.assertEqual(u.select_release(r,'2.7.99','owner/repo')['sha256'],'b'*64)
    def job(self,folder):
        folder=Path(folder);target=folder/'JuegosTorrent.exe';target.write_bytes(b'MZ'+b'o'*510)
        stage=folder/'.jt-update-test.exe';stage.write_bytes(b'MZ'+b'n'*510)
        (folder/'biblioteca.txt').write_text('NO CAMBIAR')
        return {'target':str(target),'stage':str(stage),'size':512,'sha256':u.file_hash(stage),
                'previous_sha256':u.file_hash(target),'parent_pid':123,'ready':str(folder/'helper.ready'),
                'ack':str(folder/'app.ready')}
    def wait(self,pid,ready):Path(ready).touch()
    def launch(self,path,ack=None):
        if ack:Path(ack).touch()
        return type('Process',(),{'poll':lambda self:None})()
    def replace(self,a,b):Path(a).replace(b)
    def test_apply_success(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);self.assertEqual(u.apply_update(job,self.wait,self.launch,self.replace),'ok')
            self.assertEqual(u.file_hash(job['target']),job['sha256'])
            self.assertEqual(u.file_hash(job['target']+'.bak'),job['previous_sha256'])
            self.assertEqual((Path(d)/'biblioteca.txt').read_text(),'NO CAMBIAR')
    def test_bad_hash_keeps_target(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);job['sha256']='0'*64
            with self.assertRaises(ValueError):u.apply_update(job,self.wait,self.launch,self.replace)
            self.assertEqual(u.file_hash(job['target']),job['previous_sha256'])
    def test_cancel_keeps_target(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);Path(job['ready']).with_name('cancelled').touch()
            with self.assertRaises(InterruptedError):u.apply_update(job,self.wait,self.launch,self.replace)
            self.assertEqual(u.file_hash(job['target']),job['previous_sha256'])
    def test_changed_original(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);Path(job['target']).write_bytes(b'changed')
            with self.assertRaises(ValueError):u.apply_update(job,self.wait,self.launch,self.replace)
    def test_rollback_launch_failure(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);calls=[]
            def fail_new(path,ack=None):
                calls.append(str(path))
                if ack:raise OSError('simulated launch failure')
            with self.assertRaises(OSError):u.apply_update(job,self.wait,fail_new,self.replace)
            self.assertEqual(len(calls),2);self.assertEqual(u.file_hash(job['target']),job['previous_sha256'])
    def test_rollback_early_exit(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d)
            def exited(path,ack=None):return type('P',(),{'poll':lambda self:1})()
            with self.assertRaises(RuntimeError):u.apply_update(job,self.wait,exited,self.replace)
            self.assertEqual(u.file_hash(job['target']),job['previous_sha256'])
    def test_stage_failure_rollback(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d)
            def fail_stage(a,b):
                if Path(a)==Path(job['stage']):raise OSError('simulated lock')
                Path(a).replace(b)
            with self.assertRaises(OSError):u.apply_update(job,self.wait,self.launch,fail_stage)
            self.assertEqual(u.file_hash(job['target']),job['previous_sha256'])
    def test_download(self):
        with tempfile.TemporaryDirectory() as d:
            data=b'MZ'+b'a'*510;info={'url':'https://example.invalid/exe','size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
            with patch.object(u,'urlopen',return_value=Response(data)):
                stage=u.download_update(info,Path(d)/'JuegosTorrent.exe')
            self.assertEqual(stage.read_bytes(),data)
    def test_download_mismatch_cleanup(self):
        with tempfile.TemporaryDirectory() as d:
            info={'url':'https://example.invalid/exe','size':512,'sha256':'0'*64}
            with patch.object(u,'urlopen',return_value=Response(b'MZ'+b'a'*510)):
                with self.assertRaises(ValueError):u.download_update(info,Path(d)/'JuegosTorrent.exe')
            self.assertEqual(list(Path(d).iterdir()),[])
    def test_invalid_paths(self):
        with tempfile.TemporaryDirectory() as d:
            job=self.job(d);job['stage']=str(Path(d)/'biblioteca.txt')
            with self.assertRaises(ValueError):u.apply_update(job,self.wait,self.launch,self.replace)
    def test_environment(self):self.assertEqual(u.restart_environment()['PYINSTALLER_RESET_ENVIRONMENT'],'1')

    def test_preflight_version(self):
        with tempfile.TemporaryDirectory() as d:
            stage=Path(d)/'.jt-update.exe';stage.write_bytes(b'MZ')
            def diagnostic(command,**kwargs):
                Path(command[2]).write_text(json.dumps({'compilado':True,'version':'2.8.0','carpeta_base':d}))
            with patch.object(u.subprocess,'run',side_effect=diagnostic):
                u.preflight_executable(stage,{'version':'2.8.0'})
    def test_preflight_wrong_version(self):
        with tempfile.TemporaryDirectory() as d:
            stage=Path(d)/'.jt-update.exe';stage.write_bytes(b'MZ')
            def diagnostic(command,**kwargs):
                Path(command[2]).write_text(json.dumps({'compilado':True,'version':'2.7.99','carpeta_base':d}))
            with patch.object(u.subprocess,'run',side_effect=diagnostic):
                with self.assertRaises(ValueError):u.preflight_executable(stage,{'version':'2.8.0'})
    def test_build_source_selector(self):
        import preparar_distribucion as builder
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            with patch.object(builder,'ROOT',root):
                with self.assertRaises(ValueError):builder.select_source()
                source=root/'Juegos_Torrent_Nueva.py';source.write_text("APP_VERSION = '2.8.0'")
                self.assertEqual(builder.select_source(),(source,'2.8.0'))
                (root/'Juegos_Torrent_Vieja.py').write_text("APP_VERSION = '2.7.99'")
                with self.assertRaises(ValueError):builder.select_source()
    def test_download_oversize(self):
        with tempfile.TemporaryDirectory() as d:
            info={'url':'https://example.invalid/exe','size':512,'sha256':'0'*64}
            with patch.object(u,'urlopen',return_value=Response(b'MZ'+b'a'*511)):
                with self.assertRaises(ValueError):u.download_update(info,Path(d)/'JuegosTorrent.exe')
            self.assertEqual(list(Path(d).iterdir()),[])

if __name__=='__main__':unittest.main(verbosity=2)
