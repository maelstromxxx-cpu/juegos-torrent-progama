@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 Kalakas_Catalog_Manager.py
goto resultado
:python
python Kalakas_Catalog_Manager.py
:resultado
if errorlevel 1 (
 echo.
 echo No se pudo abrir Catalog Manager. Revisa el mensaje anterior.
 echo Se necesita Python 3.10 o posterior con Tkinter.
 pause
)
popd
