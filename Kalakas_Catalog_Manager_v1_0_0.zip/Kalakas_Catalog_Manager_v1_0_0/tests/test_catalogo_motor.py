import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import catalogo_motor as motor


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.lib = self.root / 'repo'
        self.lib.mkdir()
        (self.lib / '.git').mkdir()
        for category in motor.CATEGORIES:
            (self.lib / category).mkdir()
        self.cat = self.root / 'catalogos' / 'catalogo.txt'
        self.cat.parent.mkdir()
        self.cat.write_bytes(b'# Catalogo\r\nAlpha [v1]|ID_A|INST_A\r\n---Nombre distinto|md|UP_A\r\n\r\nBeta|ID_B\r\nGamma|ID_C')
        self.reserve = self.root / 'reserva'
        self.settings = motor.Settings(self.cat, self.lib, self.reserve)
        self.assets('Alpha', b'alpha')
        self.assets('Beta', b'beta')
        self.assets('Gamma', b'gamma')

    def tearDown(self):
        self.temp.cleanup()

    def assets(self, title, content):
        for category, suffix in [('datos', '.txt'), ('sinopsis', '.txt'), ('imagenes', '.webp')]:
            (self.lib / category / (title + suffix)).write_bytes(content)
        folder = self.lib / 'capturas' / title
        folder.mkdir(parents=True, exist_ok=True)
        (folder / '01.jpg').write_bytes(content + b'screenshot')
        (folder / 'subcarpeta').mkdir(exist_ok=True)
        (folder / 'subcarpeta' / 'extra.bin').write_bytes(b'extra' + content)

    def snapshot(self, root):
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob('*') if p.is_file()}

    def plan(self, direction, titles):
        return motor.make_plan(self.settings, direction, [motor.title_key(t) for t in titles])

    def test_dry_run_does_not_write(self):
        original = self.snapshot(self.root)
        plan = self.plan('archive', ['Alpha [v1]'])
        self.assertEqual(len(plan.moves), 5)
        self.assertEqual(plan.updates, 1)
        self.assertFalse(plan.warnings)
        self.assertFalse(plan.blocks)
        self.assertEqual(original, self.snapshot(self.root))
        self.assertFalse(self.reserve.exists())

    def test_roundtrip_exact_bytes_and_assets(self):
        catalog_before = self.cat.read_bytes()
        assets_before = self.snapshot(self.lib)
        folder = motor.execute(self.plan('archive', ['Alpha [v1]', 'Gamma']))
        self.assertTrue((folder / '0_catalogo.txt.antes').is_file())
        self.assertNotIn(b'Alpha', self.cat.read_bytes())
        self.assertIn(b'---Nombre distinto|md|UP_A', (self.reserve / motor.PENDING).read_bytes())
        self.assertFalse((self.lib / 'imagenes' / 'Alpha.webp').exists())
        motor.execute(self.plan('restore', ['Gamma', 'Alpha [v1]']))
        self.assertEqual(self.cat.read_bytes(), catalog_before)
        self.assertEqual(self.snapshot(self.lib), assets_before)
        self.assertEqual(len(motor.load(self.settings)[1].records), 0)

    def test_utf8_bom_comments_and_unicode(self):
        raw = '\ufeff# título\nPokémon [v2]|ID\n---Otro título|pagina|https://a.invalid\n; nota\nBeta|B\n'.encode('utf-8')
        self.cat.write_bytes(raw)
        self.assets('Pokémon', b'unicode')
        motor.execute(self.plan('archive', ['Pokémon [v2]']))
        motor.execute(self.plan('restore', ['Pokémon [v2]']))
        self.assertEqual(self.cat.read_bytes(), raw)

    def test_distinct_destination_blocks_without_changes(self):
        motor.execute(self.plan('archive', ['Beta']))
        (self.lib / 'imagenes' / 'Beta.webp').write_bytes(b'different')
        plan = self.plan('restore', ['Beta'])
        original = self.snapshot(self.root)
        self.assertTrue(plan.blocks)
        with self.assertRaises(motor.CatalogError):
            motor.execute(plan)
        self.assertEqual(original, self.snapshot(self.root))

    def test_identical_destination_is_reused(self):
        motor.execute(self.plan('archive', ['Beta']))
        (self.lib / 'imagenes' / 'Beta.webp').write_bytes(b'beta')
        plan = self.plan('restore', ['Beta'])
        self.assertTrue(any(p.existed for p in plan.moves))
        motor.execute(plan)
        self.assertEqual((self.lib / 'imagenes' / 'Beta.webp').read_bytes(), b'beta')

    def test_shared_asset_stays_active(self):
        self.cat.write_text('Alpha [v1]|A\nAlpha [v2]|B\n', encoding='utf-8')
        motor.execute(self.plan('archive', ['Alpha [v1]']))
        self.assertEqual((self.lib / 'imagenes' / 'Alpha.webp').read_bytes(), b'alpha')
        self.assertTrue((self.reserve / 'imagenes' / 'Alpha.webp').exists())
        motor.execute(self.plan('archive', ['Alpha [v2]']))
        self.assertFalse((self.lib / 'imagenes' / 'Alpha.webp').exists())
        motor.execute(self.plan('restore', ['Alpha [v1]']))
        self.assertTrue((self.reserve / 'imagenes' / 'Alpha.webp').exists())
        motor.execute(self.plan('restore', ['Alpha [v2]']))
        self.assertFalse((self.reserve / 'imagenes' / 'Alpha.webp').exists())

    def test_catalog_edited_after_preview_is_not_overwritten(self):
        plan = self.plan('archive', ['Beta'])
        new = self.cat.read_bytes() + b'\nNew|ID\n'
        self.cat.write_bytes(new)
        with self.assertRaises(motor.CatalogError):
            motor.execute(plan)
        self.assertEqual(self.cat.read_bytes(), new)
        self.assertFalse(self.reserve.exists())

    def test_resource_edited_after_preview_is_not_moved(self):
        plan = self.plan('archive', ['Beta'])
        original_cat = self.cat.read_bytes()
        (self.lib / 'imagenes' / 'Beta.webp').write_bytes(b'modified')
        with self.assertRaises(motor.CatalogError):
            motor.execute(plan)
        self.assertEqual(self.cat.read_bytes(), original_cat)
        self.assertFalse(self.reserve.exists())

    def test_missing_categories_are_visible_warnings(self):
        (self.lib / 'imagenes' / 'Beta.webp').unlink()
        plan = self.plan('archive', ['Beta'])
        self.assertTrue(any('imagenes/' in warning for warning in plan.warnings))

    def test_reserve_inside_repo_is_rejected(self):
        for bad in [self.lib / 'reserva', self.root]:
            with self.assertRaises(motor.CatalogError):
                motor.Settings(self.cat, self.lib, bad).validate()

    def test_reserve_next_to_catalog_outside_git_is_allowed(self):
        settings = motor.Settings(self.cat, self.lib, self.cat.parent / 'reserva')
        plan = motor.make_plan(settings, 'archive', [motor.title_key('Beta')])
        motor.execute(plan)
        self.assertTrue((settings.reserve / motor.PENDING).exists())

    def test_duplicates_and_orphan_updates_are_rejected(self):
        for raw in [b'Beta|A\nbeta |B\n', b'---Update|md|ID\nBeta|A\n']:
            with self.assertRaises(motor.CatalogError):
                motor.Catalog.parse(raw)

    def test_copy_failure_rolls_back_and_allows_retry(self):
        before = self.cat.read_bytes()
        before_assets = self.snapshot(self.lib)
        original_copy = motor.checked_copy
        calls = []
        def fail_second(src, dst, sha, temporary=None):
            calls.append(src)
            if len(calls) == 2:
                raise OSError('Fallo de disco simulado')
            return original_copy(src, dst, sha, temporary)
        with mock.patch.object(motor, 'checked_copy', side_effect=fail_second):
            with self.assertRaisesRegex(motor.CatalogError, 'recuperó el estado anterior'):
                motor.execute(self.plan('archive', ['Beta']))
        self.assertEqual(before, self.cat.read_bytes())
        self.assertEqual(before_assets, self.snapshot(self.lib))
        self.assertFalse(motor.pending_transactions(self.settings))
        motor.execute(self.plan('archive', ['Beta']))
        self.assertNotIn(b'Beta|', self.cat.read_bytes())

    def test_catalog_write_failure_rolls_back(self):
        before = self.cat.read_bytes()
        assets = self.snapshot(self.lib)
        write = motor.atomic_write
        failed = []
        def fail_once(path, data):
            if Path(path) == self.cat and not failed:
                failed.append(True)
                raise OSError('Fallo de escritura simulado')
            return write(path, data)
        with mock.patch.object(motor, 'atomic_write', side_effect=fail_once):
            with self.assertRaises(motor.CatalogError):
                motor.execute(self.plan('archive', ['Alpha [v1]']))
        self.assertEqual(self.cat.read_bytes(), before)
        self.assertEqual(self.snapshot(self.lib), assets)

    def test_crash_recovery_after_catalogs_committed(self):
        before = self.cat.read_bytes()
        assets = self.snapshot(self.lib)
        write = motor.atomic_write
        def crash(path, data):
            result = write(path, data)
            if Path(path).name == 'operacion.json' and b'"status": "removing_sources"' in data:
                raise KeyboardInterrupt('Corte de proceso simulado')
            return result
        with mock.patch.object(motor, 'atomic_write', side_effect=crash):
            with self.assertRaises(KeyboardInterrupt):
                motor.execute(self.plan('archive', ['Beta']))
        self.assertEqual(len(motor.pending_transactions(self.settings)), 1)
        self.assertEqual(motor.recover(self.settings), 1)
        self.assertEqual(before, self.cat.read_bytes())
        self.assertEqual(assets, self.snapshot(self.lib))

    def test_crash_after_one_source_removed_is_recoverable(self):
        before = self.cat.read_bytes()
        assets = self.snapshot(self.lib)
        unlink = Path.unlink
        removed = []
        def crash(path, *args, **kwargs):
            result = unlink(path, *args, **kwargs)
            if path == self.lib / 'datos' / 'Beta.txt' and not removed:
                removed.append(True)
                raise KeyboardInterrupt('Corte después de mover un archivo')
            return result
        with mock.patch.object(Path, 'unlink', crash):
            with self.assertRaises(KeyboardInterrupt):
                motor.execute(self.plan('archive', ['Beta']))
        motor.recover(self.settings)
        self.assertEqual(self.cat.read_bytes(), before)
        self.assertEqual(self.snapshot(self.lib), assets)

    def test_external_catalog_edit_during_copy_is_preserved(self):
        original = motor.checked_copy
        changed = []
        def edit(src, dst, sha, temporary=None):
            result = original(src, dst, sha, temporary)
            if not changed:
                self.cat.write_bytes(self.cat.read_bytes() + b'\nExternal|ID\n')
                changed.append(True)
            return result
        with mock.patch.object(motor, 'checked_copy', side_effect=edit):
            with self.assertRaisesRegex(motor.CatalogError, 'cambios posteriores'):
                motor.execute(self.plan('archive', ['Beta']))
        self.assertIn(b'External|ID', self.cat.read_bytes())
        self.assertTrue((self.lib / 'imagenes' / 'Beta.webp').exists())
        self.assertEqual(len(motor.pending_transactions(self.settings)), 1)

    def test_reserved_asset_tampering_blocks_restore(self):
        motor.execute(self.plan('archive', ['Beta']))
        (self.reserve / 'datos' / 'Beta.txt').write_bytes(b'edited')
        plan = self.plan('restore', ['Beta'])
        self.assertTrue(plan.blocks)

    def test_other_reserve_owner_rejected(self):
        motor.execute(self.plan('archive', ['Beta']))
        other = self.root / 'other.txt'
        other.write_bytes(b'Z|ID\n')
        with self.assertRaises(motor.CatalogError):
            motor.load(motor.Settings(other, self.lib, self.reserve))

    def test_new_game_added_between_operations(self):
        motor.execute(self.plan('archive', ['Beta']))
        self.cat.write_bytes(b'New|ID\r\n' + self.cat.read_bytes())
        self.assets('New', b'new')
        motor.execute(self.plan('archive', ['New']))
        motor.execute(self.plan('restore', ['Beta', 'New']))
        self.assertEqual([r.title for r in motor.load(self.settings)[0].records], ['New', 'Alpha [v1]', 'Beta', 'Gamma'])

    @unittest.skipUnless(hasattr(Path, 'symlink_to'), 'Sin enlaces simbólicos')
    def test_symlink_resource_rejected(self):
        path = self.lib / 'imagenes' / 'Beta.webp'
        path.unlink()
        try:
            path.symlink_to(self.lib / 'imagenes' / 'Alpha.webp')
        except OSError:
            self.skipTest('Sin permiso para crear enlaces')
        with self.assertRaises(motor.CatalogError):
            self.plan('archive', ['Beta'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
