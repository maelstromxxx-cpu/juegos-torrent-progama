"""Kalaka's Catalog Manager — ejecutar con Python 3.10+ / Tkinter."""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from catalogo_motor import (VERSION, CatalogError, Settings, execute, load,
                            make_plan, pending_transactions, recover)

BG = '#0a111c'
PANEL = '#111e2d'
CARD = '#182b3e'
FG = '#edf5fc'
MUTED = '#9bb1c7'
TEAL = '#33d9b1'
BLUE = '#48a4ff'
GOLD = '#ffcf72'
CONFIG = Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'KalakasSoft' / 'CatalogManager' / 'config.json'


class Preview(tk.Toplevel):
    def __init__(self, owner, plan):
        super().__init__(owner)
        self.owner, self.plan = owner, plan
        self.title('Vista previa | Kalaka\'s Catalog Manager')
        self.configure(bg=BG)
        self.geometry(f'{min(900, owner.winfo_screenwidth()-80)}x{min(640, owner.winfo_screenheight()-100)}')
        self.minsize(640, 430)
        self.transient(owner)
        self.grab_set()
        tk.Label(self, text='REVISÁ LA OPERACIÓN', bg=BG, fg=TEAL,
                 font=('Segoe UI', 15, 'bold')).pack(anchor='w', padx=22, pady=(18, 5))
        tk.Label(self, text='Todavía no se movió ningún archivo.', bg=BG, fg=MUTED,
                 font=('Segoe UI', 10)).pack(anchor='w', padx=22, pady=(0, 12))
        box = ttk.Frame(self)
        box.pack(fill='both', expand=True, padx=22)
        text = tk.Text(box, wrap='word', bg=PANEL, fg=FG, insertbackground=FG,
                       font=('Consolas', 10), relief='flat', padx=14, pady=12)
        scroll = ttk.Scrollbar(box, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        text.pack(fill='both', expand=True)
        text.insert('1.0', plan.summary())
        text.configure(state='disabled')
        self.approved = tk.BooleanVar(value=False)
        if plan.warnings and not plan.blocks and not owner.simulation.get():
            ttk.Checkbutton(self, text='Revisé los avisos y acepto continuar con los recursos encontrados.',
                            variable=self.approved).pack(anchor='w', padx=22, pady=(12, 0))
        footer = ttk.Frame(self)
        footer.pack(fill='x', padx=22, pady=16)
        ttk.Button(footer, text='Guardar informe…', command=self.export).pack(side='left')
        ttk.Button(footer, text='Cerrar', command=self.destroy).pack(side='right')
        if not owner.simulation.get() and not plan.blocks:
            action = 'Archivar ahora' if plan.direction == 'archive' else 'Restaurar ahora'
            ttk.Button(footer, text=action, style='Accent.TButton', command=self.apply).pack(side='right', padx=10)
        else:
            label = 'Hay conflictos: no se puede aplicar.' if plan.blocks else 'SIMULACIÓN · No modifica el catálogo ni sus recursos.'
            tk.Label(self, text=label, bg=BG, fg=GOLD, font=('Segoe UI', 10)).pack(pady=(0, 12))

    def export(self):
        path = filedialog.asksaveasfilename(parent=self, title='Guardar simulación',
                                          initialfile='Simulacion_Catalog_Manager.txt',
                                          defaultextension='.txt', filetypes=[('Texto', '*.txt')])
        if path:
            try:
                Path(path).write_text(self.plan.summary(), encoding='utf-8-sig')
            except OSError as exc:
                messagebox.showerror('No se pudo guardar', str(exc), parent=self)

    def apply(self):
        if self.plan.warnings and not self.approved.get():
            messagebox.showinfo('Revisá los avisos', 'Marcá la casilla después de revisar qué recursos faltan.', parent=self)
            return
        plan = self.plan
        self.destroy()
        self.owner.run_task(lambda: execute(plan, self.owner.progress), 'Ejecutando operación…', 'done')


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Kalaka's Catalog Manager {VERSION}")
        self.geometry(f'{min(1180, self.winfo_screenwidth()-80)}x{min(830, self.winfo_screenheight()-100)}')
        self.minsize(900, 640)
        self.configure(bg=BG)
        self.option_add('*Font', ('Segoe UI', 10))
        self.events = queue.Queue()
        self.busy = False
        self.active, self.pending, self.plan = [], [], None
        self.paths = [tk.StringVar() for _ in range(3)]
        self.search = tk.StringVar()
        self.simulation = tk.BooleanVar(value=True)
        self.status = tk.StringVar(value='Elegí el catálogo, la biblioteca y una carpeta de reserva vacía.')
        self.style_widgets()
        self.create_widgets()
        self.read_config()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(100, self.poll)

    def style_widgets(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', background=BG, foreground=FG, font=('Segoe UI', 10))
        style.configure('TFrame', background=BG)
        style.configure('TLabel', background=BG, foreground=FG)
        style.configure('TEntry', fieldbackground=PANEL, foreground=FG, insertcolor=FG,
                        padding=7, bordercolor=CARD, lightcolor=CARD, darkcolor=CARD)
        style.configure('TButton', background=CARD, foreground=FG, padding=(12, 8),
                        borderwidth=1, bordercolor='#33516b')
        style.map('TButton', background=[('active', '#27445f'), ('disabled', PANEL)],
                  foreground=[('disabled', '#667c91')])
        style.configure('Accent.TButton', background='#087b69', foreground='#ffffff', padding=(18, 10))
        style.map('Accent.TButton', background=[('active', '#109c83')])
        style.configure('TCheckbutton', background=BG, foreground=GOLD)
        style.map('TCheckbutton', background=[('active', BG)])
        style.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=FG,
                        rowheight=31, borderwidth=0)
        style.map('Treeview', background=[('selected', '#165c7a')], foreground=[('selected', '#ffffff')])
        style.configure('Treeview.Heading', background=CARD, foreground=FG, padding=8, relief='flat')
        style.configure('Horizontal.TProgressbar', background=TEAL, troughcolor=PANEL)

    def create_widgets(self):
        header = ttk.Frame(self)
        header.pack(fill='x', padx=24, pady=(20, 15))
        tk.Label(header, text="KALAKA'S SOFT", bg=BG, fg=TEAL,
                 font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(header, text='Catalog Manager', bg=BG, fg=FG,
                 font=('Segoe UI', 25, 'bold')).pack(side='left')
        tk.Label(header, text=f'RESERVA LOCAL  ·  v{VERSION}', bg=BG, fg=MUTED,
                 font=('Segoe UI', 10)).pack(side='right', anchor='s', pady=8)
        paths = ttk.Frame(self)
        paths.pack(fill='x', padx=24)
        paths.columnconfigure(1, weight=1)
        self.path_entries = []
        for i, label in enumerate(('Catálogo activo', 'Biblioteca local', 'Reserva fuera del repo')):
            ttk.Label(paths, text=label).grid(row=i, column=0, sticky='w', padx=(0, 12), pady=4)
            entry = ttk.Entry(paths, textvariable=self.paths[i])
            entry.grid(row=i, column=1, sticky='ew', pady=4)
            self.path_entries.append(entry)
            ttk.Button(paths, text='Elegir…', command=lambda n=i: self.choose(n)).grid(row=i, column=2, padx=(10, 0))
        actions = ttk.Frame(self)
        actions.pack(fill='x', padx=24, pady=(10, 12))
        self.load_button = ttk.Button(actions, text='Cargar / Recargar listas', command=self.reload)
        self.load_button.pack(side='left')
        ttk.Button(actions, text='Abrir reserva', command=self.open_reserve).pack(side='left', padx=8)
        ttk.Button(actions, text='Recuperar operación', command=self.recover).pack(side='left')
        ttk.Checkbutton(actions, text='Modo simulación', variable=self.simulation).pack(side='right')
        find = ttk.Frame(self)
        find.pack(fill='x', padx=24, pady=(0, 12))
        ttk.Label(find, text='Buscar juego').pack(side='left', padx=(0, 12))
        ttk.Entry(find, textvariable=self.search).pack(side='left', fill='x', expand=True)
        ttk.Button(find, text='Limpiar', command=lambda: self.search.set('')).pack(side='left', padx=(10, 0))
        self.search.trace_add('write', lambda *_: self.populate())
        tables = ttk.Panedwindow(self, orient='horizontal')
        tables.pack(fill='both', expand=True, padx=24)
        self.trees, self.counts = [], []
        for i, title in enumerate(('CATÁLOGO ACTIVO', 'JUEGOS EN RESERVA')):
            panel = ttk.Frame(tables)
            tables.add(panel, weight=1)
            caption = tk.Label(panel, text=title, bg=BG, fg=BLUE if i == 0 else TEAL,
                               font=('Segoe UI', 12, 'bold'), anchor='w')
            caption.pack(fill='x', pady=(0, 8))
            body = ttk.Frame(panel)
            body.pack(fill='both', expand=True, padx=(0, 8) if i == 0 else (8, 0))
            tree = ttk.Treeview(body, columns=('title', 'updates'), show='headings', selectmode='extended')
            tree.heading('title', text='Juego')
            tree.heading('updates', text='Extras')
            tree.column('title', width=365, minwidth=160, stretch=True)
            tree.column('updates', width=60, minwidth=55, stretch=False, anchor='center')
            ys = ttk.Scrollbar(body, orient='vertical', command=tree.yview)
            xs = ttk.Scrollbar(body, orient='horizontal', command=tree.xview)
            tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
            body.columnconfigure(0, weight=1)
            body.rowconfigure(0, weight=1)
            tree.grid(row=0, column=0, sticky='nsew')
            ys.grid(row=0, column=1, sticky='ns')
            xs.grid(row=1, column=0, sticky='ew')
            tree.bind('<<TreeviewSelect>>', lambda _, n=i: self.selection_changed(n))
            tree.bind('<Control-a>', lambda _, widget=tree: self.select_all(widget))
            tree.bind('<Double-1>', lambda _, n=i: self.details(n))
            self.trees.append(tree)
            count = tk.StringVar()
            self.counts.append(count)
            ttk.Label(panel, textvariable=count).pack(anchor='w', pady=7)
            label = 'Vista previa: archivar →' if i == 0 else '← Vista previa: restaurar'
            ttk.Button(panel, text=label, style='Accent.TButton',
                       command=lambda n=i: self.preview(n)).pack(fill='x', padx=(0, 8) if i == 0 else (8, 0), pady=(0, 8))
        tk.Label(self, text='Ctrl / Shift: varios juegos   ·   Ctrl+A: todos los visibles   ·   Doble clic: título completo',
                 bg=BG, fg=MUTED, font=('Segoe UI', 9)).pack(anchor='w', padx=24, pady=(8, 4))
        tk.Label(self, text='Drive queda intacto. Después de archivar/restaurar: regenerar biblioteca.json y publicar los cambios.',
                 bg=BG, fg=GOLD, font=('Segoe UI', 9), anchor='w').pack(fill='x', padx=24, pady=(0, 8))
        self.bar = ttk.Progressbar(self, mode='indeterminate')
        self.bar.pack(fill='x', padx=24)
        tk.Label(self, textvariable=self.status, bg=BG, fg=MUTED, anchor='w',
                 wraplength=1080, font=('Segoe UI', 9)).pack(fill='x', padx=24, pady=(8, 15))

    def select_all(self, tree):
        tree.selection_set(tree.get_children())
        return 'break'

    def settings(self):
        if not all(value.get().strip() for value in self.paths):
            raise CatalogError('Completá las tres rutas antes de continuar.')
        return Settings(*(Path(value.get().strip().strip('"')) for value in self.paths))

    def choose(self, index):
        if self.busy:
            return
        if index == 0:
            value = filedialog.askopenfilename(title='Elegir catalogo.txt', filetypes=[('Catálogo de texto', '*.txt'), ('Todos', '*')])
        else:
            value = filedialog.askdirectory(title='Elegir biblioteca local' if index == 1 else 'Elegir reserva vacía y fuera del repo', mustexist=False)
        if not value:
            return
        self.paths[index].set(value)
        if index == 1 and not self.paths[2].get():
            root = Path(value)
            parent = next((p.parent for p in (root, *root.parents) if (p / '.git').exists()), root.parent)
            self.paths[2].set(str(parent / 'Juegos_Pendientes'))
        self.active, self.pending = [], []
        self.populate()

    def read_config(self):
        try:
            data = json.loads(CONFIG.read_text(encoding='utf-8'))
            for variable, key in zip(self.paths, ('catalogo', 'biblioteca', 'reserva')):
                variable.set(data.get(key, ''))
        except (OSError, ValueError):
            pass

    def save_config(self):
        try:
            CONFIG.parent.mkdir(parents=True, exist_ok=True)
            CONFIG.write_text(json.dumps(dict(zip(('catalogo', 'biblioteca', 'reserva'),
                                                  [v.get() for v in self.paths])), ensure_ascii=False, indent=2), encoding='utf-8')
        except OSError:
            pass

    def reload(self):
        if self.busy:
            return
        try:
            settings = self.settings()
        except CatalogError as exc:
            messagebox.showerror('Revisá las rutas', str(exc), parent=self)
            return
        self.run_task(lambda: (settings, load(settings), pending_transactions(settings)), 'Leyendo catálogos…', 'loaded')

    def populate(self):
        query = self.search.get().casefold().strip()
        for index, records in enumerate((self.active, self.pending)):
            tree = self.trees[index]
            selected = set(tree.selection())
            tree.delete(*tree.get_children())
            for record in records:
                if query in record.title.casefold():
                    tree.insert('', 'end', iid=record.key, values=(record.title, record.updates))
            tree.selection_set([key for key in selected if tree.exists(key)])
            self.counts[index].set(f'{len(records)} juegos · {len(tree.get_children())} visibles · {len(tree.selection())} seleccionados')

    def selection_changed(self, index):
        records = (self.active, self.pending)[index]
        tree = self.trees[index]
        self.counts[index].set(f'{len(records)} juegos · {len(tree.get_children())} visibles · {len(tree.selection())} seleccionados')

    def details(self, index):
        selection = self.trees[index].selection()
        if selection:
            record = next(r for r in (self.active, self.pending)[index] if r.key == selection[0])
            messagebox.showinfo('Juego seleccionado', f'{record.title}\n\n{record.updates} complementos/updates.\nEl bloque se conserva completo, con sus IDs.', parent=self)

    def preview(self, index):
        if self.busy:
            return
        selected = self.trees[index].selection()
        if not selected:
            messagebox.showinfo('Seleccioná juegos', 'Seleccioná uno o varios juegos de esa lista.', parent=self)
            return
        try:
            settings = self.settings()
        except CatalogError as exc:
            messagebox.showerror('Revisá las rutas', str(exc), parent=self)
            return
        self.run_task(lambda: make_plan(settings, 'archive' if index == 0 else 'restore', selected),
                      'Buscando recursos y verificando archivos…', 'preview')

    def progress(self, message):
        self.events.put(('progress', message))

    def run_task(self, function, label, result):
        if self.busy:
            return
        self.busy = True
        self.status.set(label)
        self.bar.start(12)
        for entry in self.path_entries:
            entry.configure(state='disabled')
        def worker():
            try:
                self.events.put((result, function()))
            except Exception as exc:
                self.events.put(('error', str(exc)))
        threading.Thread(target=worker, daemon=False).start()

    def poll(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == 'progress':
                    self.status.set(data)
                    continue
                self.busy = False
                self.bar.stop()
                for entry in self.path_entries:
                    entry.configure(state='normal')
                if kind == 'error':
                    self.status.set('La operación no se completó. Revisá el mensaje de diagnóstico.')
                    messagebox.showerror('Catalog Manager', data, parent=self)
                elif kind == 'loaded':
                    settings, (active, pending, _), interrupted = data
                    self.active, self.pending = active.records, pending.records
                    self.populate()
                    self.save_config()
                    self.status.set(f'{len(self.active)} juegos activos · {len(self.pending)} en reserva. Modo simulación activado.'
                                    if self.simulation.get() else 'Listas cargadas. Cada operación requiere revisar su vista previa.')
                    if interrupted:
                        messagebox.showwarning('Operación interrumpida', 'Se encontró una operación sin terminar. Usá Recuperar operación antes de mover más juegos.', parent=self)
                elif kind == 'preview':
                    self.status.set('Vista previa lista. Todavía no se modificó el catálogo ni sus recursos.')
                    Preview(self, data)
                elif kind == 'done':
                    messagebox.showinfo('Operación completada',
                        'Juegos y recursos verificados.\n\nAhora regenerá biblioteca.json con tu preparador habitual y publicá los cambios de la biblioteca y catalogo.txt.\n\nRespaldo y registro:\n' + str(data), parent=self)
                    self.reload()
                elif kind == 'recovered':
                    messagebox.showinfo('Recuperación terminada', f'Se recuperaron {data} operaciones interrumpidas.', parent=self)
                    self.reload()
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def recover(self):
        if self.busy:
            return
        try:
            settings = self.settings()
            settings.validate()
            jobs = pending_transactions(settings)
            if not jobs:
                raise CatalogError('No hay operaciones interrumpidas para recuperar.')
        except (CatalogError, OSError) as exc:
            messagebox.showinfo('Recuperar operación', str(exc), parent=self)
            return
        if messagebox.askyesno('Recuperar operación',
                              f'Hay {len(jobs)} operaciones interrumpidas. ¿Restaurar sus catálogos y recursos al estado anterior?\n\nSi encuentra cambios externos posteriores, se detendrá para conservarlos.', parent=self):
            self.run_task(lambda: recover(settings), 'Recuperando estado anterior…', 'recovered')

    def open_reserve(self):
        if self.busy:
            return
        path = Path(self.paths[2].get())
        if not self.paths[2].get() or not path.is_dir():
            messagebox.showinfo('Reserva', 'La reserva se creará al aplicar el primer archivado. La simulación no la crea.', parent=self)
            return
        try:
            if sys.platform == 'win32':
                os.startfile(str(path))
            else:
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', str(path)])
        except OSError as exc:
            messagebox.showerror('No se pudo abrir', str(exc), parent=self)

    def close(self):
        if self.busy:
            messagebox.showinfo('Operación en curso', 'Esperá a que termine para cerrar el administrador.', parent=self)
            return
        self.destroy()


if __name__ == '__main__':
    App().mainloop()
