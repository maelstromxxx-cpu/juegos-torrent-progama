"""Archivo/restauración local. No conecta a Drive, GitHub ni al gestor."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import sys
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path

VERSION = '1.0.0'
CATEGORIES = ('datos', 'sinopsis', 'imagenes', 'capturas')
INDEX = 'reserva.json'
IDENTITY = '.kalaka_reserva.json'
PENDING = 'catalogo_pendientes.txt'
HISTORY = 'operaciones'
MARKER = '.kalaka_catalog_manager.lock'


class CatalogError(Exception):
    pass


def digest(data):
    return hashlib.sha256(data).hexdigest()


def hash_file(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def title_key(title):
    return ' '.join(title.split()).casefold()


def stems(title):
    # Mismas variantes que image_stems del gestor: exacta y sin [...].
    def clean(value):
        return re.sub(r'[\\/:*?"<>|]', '_', value).strip().rstrip(' .')
    values = [clean(title), clean(re.sub(r'\s*\[[^]]*\]', '', title))]
    return {title_key(s) for s in values if s and s not in ('.', '..')}


def blocked_link(path):
    if path.is_symlink() or bool(getattr(path, 'is_junction', lambda: False)()):
        return True
    if sys.platform == 'win32' and path.exists():
        # Python 3.10/3.11 todavía no tienen Path.is_junction().
        return bool(getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)
    return False


def safe_path(path):
    path = Path(os.path.abspath(path))
    for item in (path, *path.parents):
        if blocked_link(item):
            raise CatalogError(f'No se admiten enlaces simbólicos o junctions: {item}')
    return path.resolve()


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('xb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


@dataclass
class Record:
    title: str
    raw: bytes
    updates: int

    @property
    def key(self):
        return title_key(self.title)


@dataclass
class Catalog:
    raw: bytes
    prefix: bytes
    records: list[Record]
    bom: bytes = b''
    newline: bytes = b'\n'

    @classmethod
    def parse(cls, raw):
        bom = b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b''
        content = raw[len(bom):]
        try:
            content.decode('utf-8')
        except UnicodeDecodeError as exc:
            raise CatalogError('El catálogo debe estar guardado como UTF-8.') from exc
        records, prefix, current, seen = [], [], None, set()
        for number, line in enumerate(content.splitlines(keepends=True), 1):
            text = line.decode('utf-8').strip()
            if text and not text.startswith(('#', ';', '---')):
                parts = text.split('|')
                if len(parts) < 2 or not parts[0].strip() or not parts[1].strip():
                    raise CatalogError(f'Línea {number} no reconocida: {text[:90]}')
                title = parts[0].strip()
                key = title_key(title)
                if key in seen:
                    raise CatalogError(f'Juego duplicado en el mismo catálogo: {title}')
                seen.add(key)
                current = Record(title, line, 0)
                records.append(current)
            elif current is not None:
                current.raw += line
                if text.startswith('---'):
                    current.updates += 1
            elif text.startswith('---'):
                raise CatalogError(f'Update sin juego principal en línea {number}.')
            else:
                prefix.append(line)
        return cls(raw, b''.join(prefix), records, bom,
                   b'\r\n' if b'\r\n' in content else b'\n')

    def render(self, records):
        result = self.prefix
        for record in records:
            if result and not result.endswith((b'\n', b'\r')):
                result += self.newline
            result += record.raw
        return self.bom + result


@dataclass
class Settings:
    catalog: Path
    library: Path
    reserve: Path

    def validate(self):
        self.catalog, self.library, self.reserve = [
            safe_path(p) for p in (self.catalog, self.library, self.reserve)]
        if not self.catalog.is_file():
            raise CatalogError('Elegí tu catalogo.txt existente.')
        if not self.library.is_dir() or not any((self.library / c).is_dir() for c in CATEGORIES):
            raise CatalogError('La biblioteca debe contener datos, sinopsis, imagenes o capturas.')
        if (self.reserve == self.library or self.reserve.is_relative_to(self.library)
                or self.library.is_relative_to(self.reserve) or self.catalog.is_relative_to(self.reserve)):
            raise CatalogError('La reserva debe estar fuera de la biblioteca y no contener el catálogo activo.')
        for root in (self.library, self.catalog.parent):
            for parent in (root, *root.parents):
                if (parent / '.git').exists() and self.reserve.is_relative_to(parent):
                    raise CatalogError('La reserva debe quedar fuera del repositorio Git publicado.')
        if self.reserve.exists() and not self.reserve.is_dir():
            raise CatalogError('La reserva debe ser una carpeta.')
        # Tampoco aceptar una reserva dentro de otro repositorio Git.
        if any((p / '.git').exists() for p in (self.reserve, *self.reserve.parents)):
            raise CatalogError('Elegí una reserva fuera de repositorios Git.')
        identity = self.reserve / IDENTITY
        if identity.exists():
            try:
                owner = json.loads(safe_path(identity).read_text(encoding='utf-8'))
                if (Path(owner['catalogo']).resolve() != self.catalog
                        or Path(owner['biblioteca']).resolve() != self.library):
                    raise CatalogError('Esa reserva pertenece a otro catálogo o biblioteca.')
            except (ValueError, KeyError, OSError) as exc:
                raise CatalogError('La identificación de la reserva está dañada.') from exc
        if (self.reserve.exists() and any(self.reserve.iterdir())
                and not (self.reserve / INDEX).is_file() and not identity.is_file()):
            raise CatalogError('Usá una carpeta de reserva vacía o creada por este administrador.')
        return self


def read_optional(path):
    return path.read_bytes() if path.exists() else None


def read_index(settings):
    path = safe_path(settings.reserve / INDEX)
    if not path.exists():
        return {'schema': 1, 'catalogo': str(settings.catalog), 'biblioteca': str(settings.library),
                'order': [], 'games': {}}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if (data['schema'] != 1 or not isinstance(data['games'], dict)
                or not isinstance(data['order'], list)):
            raise ValueError('estructura inválida')
        if (Path(data['catalogo']).resolve() != settings.catalog
                or Path(data['biblioteca']).resolve() != settings.library):
            raise CatalogError('Esa reserva pertenece a otro catálogo o biblioteca.')
        return data
    except (KeyError, TypeError, ValueError, OSError) as exc:
        raise CatalogError(f'No se pudo leer {path}: {exc}') from exc


def load(settings):
    settings.validate()
    active = Catalog.parse(settings.catalog.read_bytes())
    pending = Catalog.parse(read_optional(safe_path(settings.reserve / PENDING)) or b'')
    index = read_index(settings)
    if {r.key for r in pending.records} != set(index['games']):
        raise CatalogError('El catálogo de reserva y reserva.json no coinciden. No edites la reserva manualmente.')
    for record in pending.records:
        try:
            info = index['games'][record.key]
            if digest(record.raw) != info['record_sha256']:
                raise CatalogError(f'Un bloque de reserva fue editado manualmente: {record.title}')
            for asset in info['assets']:
                rel = Path(asset['path'])
                if rel.is_absolute() or '..' in rel.parts or rel.parts[0] not in CATEGORIES:
                    raise ValueError('ruta de recurso inválida')
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            raise CatalogError(f'Registro de reserva inválido: {record.title}') from exc
    return active, pending, index


def inventory(root):
    """Índice exacto por stem. Nunca hace coincidencias parciales de títulos."""
    result = {category: {} for category in CATEGORIES}
    for category in CATEGORIES:
        folder = root / category
        if not folder.exists():
            continue
        safe_path(folder)
        for item in folder.iterdir():
            safe_path(item)
            if category == 'capturas' and item.is_dir():
                files = []
                for child in item.rglob('*'):
                    safe_path(child)
                    if child.is_file():
                        files.append(child)
                result[category].setdefault(title_key(item.name), []).extend(files)
            elif category != 'capturas' and item.is_file():
                result[category].setdefault(title_key(item.stem), []).append(item)
    return result


def resource_paths(record, listing):
    return {p for category in CATEGORIES for stem in stems(record.title)
            for p in listing[category].get(stem, [])}


@dataclass
class Move:
    relative: str
    sha256: str
    size: int
    keep_source: bool
    existed: bool


@dataclass
class Plan:
    settings: Settings
    direction: str
    titles: list[str]
    moves: list[Move]
    warnings: list[str]
    before: dict[str, bytes | None]
    after: dict[str, bytes]
    games: int
    updates: int
    blocks: list[str] = field(default_factory=list)

    @property
    def source(self):
        return self.settings.library if self.direction == 'archive' else self.settings.reserve

    @property
    def destination(self):
        return self.settings.reserve if self.direction == 'archive' else self.settings.library

    def summary(self):
        action = 'ARCHIVAR' if self.direction == 'archive' else 'RESTAURAR'
        size = sum(m.size for m in self.moves)
        lines = [f'{action} · {self.games} juegos · {self.updates} complementos/updates',
                 f'{len(self.moves)} archivos · {size / 1048576:.2f} MB',
                 f'ORIGEN: {self.source}', f'DESTINO: {self.destination}', '', 'JUEGOS:']
        lines += ['  ' + title for title in self.titles]
        lines += ['', 'ARCHIVOS:']
        for item in self.moves:
            verb = 'Copiar, compartido' if item.keep_source else 'Mover'
            if item.existed:
                verb += '; destino idéntico, se reutiliza'
            lines.append(f'  {verb}: {item.relative} ({item.size:,} bytes)')
        if self.warnings:
            lines += ['', 'AVISOS:'] + ['  ' + w for w in self.warnings]
        if self.blocks:
            lines += ['', 'NO SE PUEDE APLICAR:'] + ['  ' + b for b in self.blocks]
        lines += ['', 'Drive no se modifica. El manifiesto y la publicación se realizan aparte.',
                  'Este informe todavía no ejecutó ningún movimiento.']
        return '\n'.join(lines)


def pending_transactions(settings):
    folder = settings.reserve / HISTORY
    if not folder.exists():
        return []
    result = []
    for path in sorted(folder.glob('*/operacion.json')):
        try:
            status = json.loads(path.read_text(encoding='utf-8'))['status']
        except (ValueError, KeyError, OSError):
            raise CatalogError(f'Registro de operación ilegible: {path}')
        if status not in ('completed', 'rolled_back'):
            result.append(path)
    return result


def make_plan(settings, direction, selected):
    if direction not in ('archive', 'restore'):
        raise CatalogError('Operación desconocida.')
    active, pending, index = load(settings)
    if pending_transactions(settings):
        raise CatalogError('Hay una operación interrumpida. Usá Recuperar operación antes de continuar.')
    source_catalog, target_catalog = (active, pending) if direction == 'archive' else (pending, active)
    keys = set(selected)
    chosen = [r for r in source_catalog.records if r.key in keys]
    if not chosen or len(chosen) != len(keys):
        raise CatalogError('Seleccioná juegos de una sola lista y volvé a generar la vista previa.')
    if keys & {r.key for r in target_catalog.records}:
        raise CatalogError('Un título seleccionado ya existe en el catálogo de destino.')
    source = settings.library if direction == 'archive' else settings.reserve
    destination = settings.reserve if direction == 'archive' else settings.library
    listing = inventory(source)
    chosen_paths, owners, warnings, blocks = set(), {}, [], []
    for record in source_catalog.records:
        paths = resource_paths(record, listing)
        for path in paths:
            owners.setdefault(path, set()).add(record.key)
        if record.key in keys:
            chosen_paths.update(paths)
            for category in CATEGORIES:
                if not any(p.relative_to(source).parts[0] == category for p in paths):
                    warnings.append(f'{record.title}: sin archivos en {category}/ con nombre exacto o sin corchetes.')
    moves = []
    hashes = {}
    for path in sorted(chosen_paths):
        relative = path.relative_to(source).as_posix()
        dest = safe_path(destination / relative)
        sha = hashes[path] = hash_file(path)
        existed = dest.exists()
        if existed and (not dest.is_file() or hash_file(dest) != sha):
            blocks.append(f'El destino ya tiene contenido distinto: {relative}. No se sobrescribirá.')
        moves.append(Move(relative, sha, path.stat().st_size, bool(owners[path] - keys), existed))
    if direction == 'restore':
        for record in chosen:
            expected = index['games'][record.key]
            if digest(record.raw) != expected['record_sha256']:
                blocks.append(f'El bloque de reserva fue editado: {record.title}.')
            for asset in expected['assets']:
                path = source / asset['path']
                if path not in hashes or hashes[path] != asset['sha256']:
                    blocks.append(f'Falta o cambió un recurso reservado de {record.title}: {asset["path"]}')
    # Orden de referencia persistente; nuevos juegos se insertan según el catálogo actual.
    order = index['order']
    active_keys = [r.key for r in active.records]
    for pos, key in enumerate(active_keys):
        if key not in order:
            following = next((k for k in active_keys[pos + 1:] if k in order), None)
            order.insert(order.index(following), key) if following else order.append(key)
    remaining = [r for r in source_catalog.records if r.key not in keys]
    if direction == 'archive':
        new_active, new_pending = remaining, pending.records + chosen
        if not new_active:
            warnings.append('El catálogo activo quedaría vacío. Tu preparador actual no reemplaza biblioteca.json '
                            'si no quedan recursos válidos; no publiques un manifiesto viejo por error.')
        for record in chosen:
            paths = resource_paths(record, listing)
            index['games'][record.key] = {
                'title': record.title, 'archived_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'record_sha256': digest(record.raw),
                'assets': [{'path': p.relative_to(source).as_posix(), 'sha256': hashes[p]}
                           for p in sorted(paths)]}
    else:
        new_active = list(active.records)
        ranks = {key: n for n, key in enumerate(order)}
        for record in sorted(chosen, key=lambda r: ranks.get(r.key, len(ranks))):
            position = next((n for n, r in enumerate(new_active)
                             if ranks.get(r.key, len(ranks)) > ranks.get(record.key, len(ranks))), len(new_active))
            new_active.insert(position, record)
            del index['games'][record.key]
        new_pending = remaining
    paths = [settings.catalog, settings.reserve / PENDING, settings.reserve / INDEX]
    before = {str(p): read_optional(p) for p in paths}
    after = {str(paths[0]): active.render(new_active), str(paths[1]): pending.render(new_pending),
             str(paths[2]): json_bytes(index)}
    # La reserva puede agregar LF entre bloques; guardar el hash del bloque tal como quedará allí.
    new_pending_parsed = Catalog.parse(after[str(paths[1])])
    for record in new_pending_parsed.records:
        index['games'][record.key]['record_sha256'] = digest(record.raw)
    after[str(paths[2])] = json_bytes(index)
    return Plan(settings, direction, [r.title for r in chosen], moves, warnings, before, after,
                len(chosen), sum(r.updates for r in chosen), blocks)


def pid_alive(pid):
    if sys.platform == 'win32':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return ctypes.get_last_error() != 87  # Acceso denegado: no asumir muerto.
        try:
            code = wintypes.DWORD()
            return not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


@contextmanager
def locks(settings):
    paths = [settings.library / MARKER, settings.catalog.with_name(settings.catalog.name + '.kalaka.lock')]
    acquired = []
    try:
        for path in paths:
            try:
                stream = path.open('x', encoding='utf-8')
            except FileExistsError:
                try:
                    pid = int(path.read_text(encoding='utf-8'))
                except (ValueError, OSError) as exc:
                    raise CatalogError(f'Bloqueo no reconocido: {path}') from exc
                if pid_alive(pid):
                    raise CatalogError('Otra operación del administrador sigue abierta.')
                path.unlink()
                stream = path.open('x', encoding='utf-8')
            acquired.append(path)
            with stream:
                stream.write(str(os.getpid()))
        yield
    finally:
        for path in reversed(acquired):
            path.unlink(missing_ok=True)


def checked_copy(source, destination, expected, temporary=None):
    safe_path(source)
    safe_path(destination)
    if hash_file(source) != expected:
        raise CatalogError(f'El recurso cambió después de la vista previa: {source}')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = temporary or destination.with_name('.kalaka-copy-' + uuid.uuid4().hex + '.part')
    try:
        with source.open('rb') as incoming, temporary.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing, 1024 * 1024)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        if hash_file(temporary) != expected:
            raise CatalogError(f'No se pudo verificar la copia: {destination}')
        if sys.platform == 'win32':
            os.rename(temporary, destination)  # Windows: falla si el destino ya existe.
        else:
            os.link(temporary, destination)  # POSIX: publicación exclusiva, sin sobrescribir.
    finally:
        temporary.unlink(missing_ok=True)


def rollback(journal_path):
    """Recupera una operación propia. Se niega a pisar cambios externos posteriores."""
    journal_path = Path(journal_path)
    job = json.loads(journal_path.read_text(encoding='utf-8'))
    if job['status'] in ('completed', 'rolled_back'):
        raise CatalogError('Esa operación ya terminó. Para deshacerla usá Archivar/Restaurar.')
    source, destination = Path(job['source']), Path(job['destination'])
    # Validar todo antes de empezar la recuperación.
    for item in job['files']:
        rel = Path(item['relative'])
        if rel.is_absolute() or '..' in rel.parts:
            raise CatalogError('Ruta inválida en el registro de operación.')
        src, dst = safe_path(source / rel), safe_path(destination / rel)
        if src.exists() and (not src.is_file() or hash_file(src) != item['sha256']):
            raise CatalogError(f'El origen tiene cambios externos; recuperación manual: {src}')
        if not src.exists() and (not dst.is_file() or hash_file(dst) != item['sha256']):
            raise CatalogError(f'No hay una copia íntegra para recuperar: {rel}')
        if dst.exists() and (not dst.is_file() or hash_file(dst) != item['sha256']):
            raise CatalogError(f'El destino tiene cambios externos; no se borrará: {dst}')
    for raw_path, state in job['catalogs'].items():
        current = read_optional(safe_path(raw_path))
        allowed = [None if state[k] is None else base64.b64decode(state[k]) for k in ('before', 'after')]
        if current not in allowed:
            raise CatalogError(f'El catálogo tiene cambios posteriores; no se sobrescribirá: {raw_path}')
    for item in job['files']:
        src, dst = source / item['relative'], destination / item['relative']
        if not src.exists():
            checked_copy(dst, src, item['sha256'])
    for raw_path, state in job['catalogs'].items():
        path = Path(raw_path)
        if state['before'] is None:
            path.unlink(missing_ok=True)
        else:
            atomic_write(path, base64.b64decode(state['before']))
    for item in job['files']:
        dst = destination / item['relative']
        if not item['existed'] and dst.exists():
            if not dst.is_file():
                raise CatalogError(f'El destino cambió de tipo: {dst}')
            if item.get('copy_started'):
                dst.unlink()
        temporary = item.get('temporary')
        if temporary:
            temp_path = safe_path(temporary)
            if temp_path.parent != dst.parent or not temp_path.name.startswith('.kalaka-copy-'):
                raise CatalogError('Ruta temporal inválida en el registro.')
            temp_path.unlink(missing_ok=True)
    job['status'] = 'rolled_back'
    atomic_write(journal_path, json_bytes(job))


def execute(plan, progress=lambda text: None):
    if plan.blocks:
        raise CatalogError('La vista previa tiene conflictos. No se movió nada.')
    s = plan.settings
    s.validate()
    with locks(s):
        if pending_transactions(s):
            raise CatalogError('Recuperá primero la operación interrumpida.')
        for raw_path, expected in plan.before.items():
            if read_optional(safe_path(raw_path)) != expected:
                raise CatalogError('El catálogo o la reserva cambiaron. Generá otra vista previa.')
        for item in plan.moves:
            src, dst = safe_path(plan.source / item.relative), safe_path(plan.destination / item.relative)
            if not src.is_file() or hash_file(src) != item.sha256:
                raise CatalogError(f'Cambió un recurso. Volvé a simular: {item.relative}')
            if dst.exists() != item.existed or (item.existed and (not dst.is_file() or hash_file(dst) != item.sha256)):
                raise CatalogError(f'Cambió el destino. Volvé a simular: {item.relative}')
        s.reserve.mkdir(parents=True, exist_ok=True)
        identity = s.reserve / IDENTITY
        if not identity.exists():
            atomic_write(identity, json_bytes({'catalogo': str(s.catalog), 'biblioteca': str(s.library)}))
        folder = s.reserve / HISTORY / (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8])
        folder.mkdir(parents=True)
        journal = folder / 'operacion.json'
        catalogs = {}
        for n, (path, before) in enumerate(plan.before.items()):
            if before is not None:
                atomic_write(folder / f'{n}_{Path(path).name}.antes', before)
            catalogs[path] = {'before': None if before is None else base64.b64encode(before).decode('ascii'),
                              'after': base64.b64encode(plan.after[path]).decode('ascii')}
        job = {'schema': 1, 'status': 'copying', 'direction': plan.direction,
               'source': str(plan.source), 'destination': str(plan.destination),
               'titles': plan.titles, 'catalogs': catalogs,
               'files': [dict(vars(item), copy_started=False,
                              temporary=str((plan.destination / item.relative).with_name(
                                  '.kalaka-copy-' + uuid.uuid4().hex + '.part')))
                         for item in plan.moves]}
        atomic_write(journal, json_bytes(job))
        try:
            for count, item in enumerate(job['files'], 1):
                progress(f'Comprobando y copiando {count}/{len(job["files"])}: {item["relative"]}')
                src, dst = plan.source / item['relative'], plan.destination / item['relative']
                if not item['existed']:
                    item['copy_started'] = True
                    atomic_write(journal, json_bytes(job))
                    checked_copy(src, dst, item['sha256'], Path(item['temporary']))
            # Detectar ediciones externas antes de escribir los catálogos.
            for path, expected in plan.before.items():
                if read_optional(Path(path)) != expected:
                    raise CatalogError('El catálogo fue editado durante la operación.')
            job['status'] = 'catalogs'
            atomic_write(journal, json_bytes(job))
            for path, data in plan.after.items():
                atomic_write(Path(path), data)
            job['status'] = 'removing_sources'
            atomic_write(journal, json_bytes(job))
            for item in job['files']:
                src, dst = plan.source / item['relative'], plan.destination / item['relative']
                if hash_file(src) != item['sha256'] or hash_file(dst) != item['sha256']:
                    raise CatalogError('Un recurso cambió durante la operación; se intentará recuperar.')
                if not item['keep_source']:
                    src.unlink()
            job['status'] = 'completed'
            atomic_write(journal, json_bytes(job))
            progress('Operación completada y verificada.')
            return folder
        except Exception as exc:
            try:
                rollback(journal)
            except Exception as recovery:
                raise CatalogError(f'{exc}\n\nNo se pudo completar la recuperación automática: {recovery}\nRegistro: {journal}') from exc
            raise CatalogError(f'La operación se canceló y se recuperó el estado anterior.\n{exc}') from exc


def recover(settings):
    settings.validate()
    jobs = pending_transactions(settings)
    if not jobs:
        raise CatalogError('No hay operaciones interrumpidas para recuperar.')
    with locks(settings):
        for path in reversed(jobs):
            rollback(path)
    return len(jobs)
